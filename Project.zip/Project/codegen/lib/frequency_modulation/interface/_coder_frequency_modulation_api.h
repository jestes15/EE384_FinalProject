//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: _coder_frequency_modulation_api.h
//
// GPU Coder version                    : 23.2
// CUDA/C/C++ source code generated on  : 12-Apr-2024 12:54:40
//

#ifndef _CODER_FREQUENCY_MODULATION_API_H
#define _CODER_FREQUENCY_MODULATION_API_H

// Include Files
#include "emlrt.h"
#include "mex.h"
#include "tmwtypes.h"
#include <algorithm>
#include <cstring>

// Type Definitions
struct emxArray_real_T {
  real_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

// Variable Declarations
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

// Function Declarations
void decode(emxArray_real_T *input_information, real_T sampling_frequency,
            real_T carrier_frequency, real_T freq_dev, emxArray_real_T *z);

void decode_api(const mxArray *const prhs[4], const mxArray *plhs[1]);

void encode(emxArray_real_T *input_information, real_T sampling_frequency,
            real_T carrier_frequency, real_T freq_dev, emxArray_real_T *y);

void encode_api(const mxArray *const prhs[4], const mxArray *plhs[1]);

void frequency_modulation_atexit();

void frequency_modulation_initialize();

void frequency_modulation_terminate();

void frequency_modulation_xil_shutdown();

void frequency_modulation_xil_terminate();

#endif
//
// File trailer for _coder_frequency_modulation_api.h
//
// [EOF]
//
