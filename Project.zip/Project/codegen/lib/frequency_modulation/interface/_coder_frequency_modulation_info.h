//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: _coder_frequency_modulation_info.h
//
// GPU Coder version                    : 23.2
// CUDA/C/C++ source code generated on  : 12-Apr-2024 12:54:40
//

#ifndef _CODER_FREQUENCY_MODULATION_INFO_H
#define _CODER_FREQUENCY_MODULATION_INFO_H

// Include Files
#include "mex.h"

// Function Declarations
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

#endif
//
// File trailer for _coder_frequency_modulation_info.h
//
// [EOF]
//
