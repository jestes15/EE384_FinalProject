//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: frequency_modulation_emxAPI.h
//
// GPU Coder version                    : 23.2
// CUDA/C/C++ source code generated on  : 12-Apr-2024 12:54:40
//

#ifndef FREQUENCY_MODULATION_EMXAPI_H
#define FREQUENCY_MODULATION_EMXAPI_H

// Include Files
#include "frequency_modulation_types.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>
#include <stdio.h>
#include <time.h>

// Function Declarations
extern emxArray_real_T *emxCreateND_real_T(int b_numDimensions,
                                           const int *b_size);

extern emxArray_real_T *emxCreateWrapperND_real_T(double *b_data,
                                                  int b_numDimensions,
                                                  const int *b_size);

extern emxArray_real_T *emxCreateWrapper_real_T(double *b_data, int rows,
                                                int cols);

extern emxArray_real_T *emxCreate_real_T(int rows, int cols);

extern void emxDestroyArray_real_T(emxArray_real_T *emxArray);

extern void emxInitArray_real_T(emxArray_real_T **pEmxArray,
                                int b_numDimensions);

#endif
//
// File trailer for frequency_modulation_emxAPI.h
//
// [EOF]
//
