//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: frequency_modulation_terminate.h
//
// GPU Coder version                    : 23.2
// CUDA/C/C++ source code generated on  : 12-Apr-2024 12:54:40
//

#ifndef FREQUENCY_MODULATION_TERMINATE_H
#define FREQUENCY_MODULATION_TERMINATE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>
#include <stdio.h>
#include <time.h>

// Function Declarations
extern void frequency_modulation_terminate();

#endif
//
// File trailer for frequency_modulation_terminate.h
//
// [EOF]
//
