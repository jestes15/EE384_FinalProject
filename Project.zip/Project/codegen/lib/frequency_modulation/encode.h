//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: encode.h
//
// GPU Coder version                    : 23.2
// CUDA/C/C++ source code generated on  : 12-Apr-2024 12:54:40
//

#ifndef ENCODE_H
#define ENCODE_H

// Include Files
#include "frequency_modulation_types.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>
#include <stdio.h>
#include <time.h>

// Function Declarations
extern void encode(const emxArray_real_T *cpu_input_information,
                   double sampling_frequency, double carrier_frequency,
                   double freq_dev, emxArray_real_T *cpu_y);

#endif
//
// File trailer for encode.h
//
// [EOF]
//
