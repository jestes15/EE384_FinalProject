//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: frequency_modulation_emxutil.h
//
// GPU Coder version                    : 23.2
// CUDA/C/C++ source code generated on  : 12-Apr-2024 12:54:40
//

#ifndef FREQUENCY_MODULATION_EMXUTIL_H
#define FREQUENCY_MODULATION_EMXUTIL_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>
#include <stdio.h>
#include <time.h>

struct emxArray_real_T;

struct emxArray_creal_T;

// Function Declarations
extern void emxEnsureCapacity_creal_T(emxArray_creal_T *emxArray, int oldNumel);

extern void emxEnsureCapacity_real_T(emxArray_real_T *emxArray, int oldNumel);

extern void emxFree_creal_T(emxArray_creal_T **pEmxArray);

extern void emxFree_real_T(emxArray_real_T **pEmxArray);

extern void emxInit_creal_T(emxArray_creal_T **pEmxArray, int b_numDimensions);

extern void emxInit_real_T(emxArray_real_T **pEmxArray, int b_numDimensions);

#endif
//
// File trailer for frequency_modulation_emxutil.h
//
// [EOF]
//
