//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: frequency_modulation_rtwutil.h
//
// GPU Coder version                    : 23.2
// CUDA/C/C++ source code generated on  : 12-Apr-2024 12:54:40
//

#ifndef FREQUENCY_MODULATION_RTWUTIL_H
#define FREQUENCY_MODULATION_RTWUTIL_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>
#include <stdio.h>
#include <time.h>

struct emxArray_real_T;

// Function Declarations
extern void commitKernelTiming(const char *kname, unsigned long blocks,
                               unsigned long grids, float time_ms,
                               const char *parent);

extern void commitMemcpyTiming(const char *kname, unsigned long b_size,
                               float time_ms, boolean_T isIO,
                               const char *parent);

extern void commitMiscTiming(const char *kname, float time_ms,
                             const char *parent);

extern void ensureTimingFileOpen();

extern void gpuCloseTiming(const char *fname);

extern void gpuEmxEnsureCapacity_real_T(const emxArray_real_T *cpu,
                                        emxArray_real_T *gpu);

extern void gpuEmxFree_real_T(emxArray_real_T *gpu);

extern void gpuEmxMemcpyCpuToGpu_real_T(emxArray_real_T *gpu,
                                        const emxArray_real_T *cpu);

extern void gpuEmxMemcpyGpuToCpu_real_T(emxArray_real_T *cpu,
                                        emxArray_real_T *gpu);

extern void gpuEmxReset_real_T(emxArray_real_T *gpu);

extern void gpuInitTiming();

#endif
//
// File trailer for frequency_modulation_rtwutil.h
//
// [EOF]
//
