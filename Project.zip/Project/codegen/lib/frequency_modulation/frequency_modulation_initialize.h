//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: frequency_modulation_initialize.h
//
// GPU Coder version                    : 23.2
// CUDA/C/C++ source code generated on  : 12-Apr-2024 12:54:40
//

#ifndef FREQUENCY_MODULATION_INITIALIZE_H
#define FREQUENCY_MODULATION_INITIALIZE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>
#include <stdio.h>
#include <time.h>

// Function Declarations
extern void frequency_modulation_initialize();

#endif
//
// File trailer for frequency_modulation_initialize.h
//
// [EOF]
//
