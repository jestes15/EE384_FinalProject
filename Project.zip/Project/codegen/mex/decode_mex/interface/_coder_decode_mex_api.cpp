//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_decode_mex_api.cpp
//
// Code generation for function '_coder_decode_mex_api'
//

// Include files
#include "_coder_decode_mex_api.h"
#include "decode.h"
#include "decode_mex_data.h"
#include "decode_mex_emxutil.h"
#include "decode_mex_types.h"
#include "encode.h"
#include "rt_nonfinite.h"

// Variable Definitions
static emlrtRTEInfo ab_emlrtRTEI{
    1,                       // lineNo
    1,                       // colNo
    "_coder_decode_mex_api", // fName
    ""                       // pName
};

// Function Declarations
static void b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                               const emlrtMsgIdentifier *msgId,
                               emxArray_real_T *ret);

static real_T b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                 const emlrtMsgIdentifier *msgId);

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                             const char_T *identifier, emxArray_real_T *y);

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                             const emlrtMsgIdentifier *parentId,
                             emxArray_real_T *y);

static real_T emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                               const char_T *identifier);

static real_T emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                               const emlrtMsgIdentifier *parentId);

static const mxArray *emlrt_marshallOut(const emxArray_real_T *u);

// Function Definitions
static void b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                               const emlrtMsgIdentifier *msgId,
                               emxArray_real_T *ret)
{
  static const int32_T dims{-1};
  int32_T i;
  int32_T i1;
  boolean_T b{true};
  emlrtCheckVsBuiltInR2012b((emlrtConstCTX)&sp, msgId, src, "double", false, 1U,
                            (const void *)&dims, &b, &i);
  ret->allocatedSize = i;
  i1 = ret->size[0];
  ret->size[0] = i;
  emxEnsureCapacity_real_T(&sp, ret, i1, static_cast<emlrtRTEInfo *>(nullptr));
  ret->data = static_cast<real_T *>(emlrtMxGetData(src));
  ret->canFreeData = false;
  emlrtDestroyArray(&src);
}

static real_T b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                 const emlrtMsgIdentifier *msgId)
{
  static const int32_T dims{0};
  real_T ret;
  emlrtCheckBuiltInR2012b((emlrtConstCTX)&sp, msgId, src, "double", false, 0U,
                          (const void *)&dims);
  ret = *static_cast<real_T *>(emlrtMxGetData(src));
  emlrtDestroyArray(&src);
  return ret;
}

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                             const char_T *identifier, emxArray_real_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = nullptr;
  thisId.bParentIsCell = false;
  emlrt_marshallIn(sp, emlrtAlias(b_nullptr), &thisId, y);
  emlrtDestroyArray(&b_nullptr);
}

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                             const emlrtMsgIdentifier *parentId,
                             emxArray_real_T *y)
{
  b_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static real_T emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                               const char_T *identifier)
{
  emlrtMsgIdentifier thisId;
  real_T y;
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = nullptr;
  thisId.bParentIsCell = false;
  y = emlrt_marshallIn(sp, emlrtAlias(b_nullptr), &thisId);
  emlrtDestroyArray(&b_nullptr);
  return y;
}

static real_T emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                               const emlrtMsgIdentifier *parentId)
{
  real_T y;
  y = b_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static const mxArray *emlrt_marshallOut(const emxArray_real_T *u)
{
  static const int32_T i{0};
  const mxArray *m;
  const mxArray *y;
  const real_T *u_data;
  u_data = u->data;
  y = nullptr;
  m = emlrtCreateNumericArray(1, (const void *)&i, mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m, (void *)&u_data[0]);
  emlrtSetDimensions((mxArray *)m, &u->size[0], 1);
  emlrtAssign(&y, m);
  return y;
}

void decode_api(const mxArray *const prhs[4], const mxArray **plhs)
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  emxArray_real_T *input_information;
  emxArray_real_T *z;
  real_T carrier_frequency;
  real_T freq_dev;
  real_T sampling_frequency;
  st.tls = emlrtRootTLSGlobal;
  emlrtHeapReferenceStackEnterFcnR2012b(&st);
  // Marshall function inputs
  emxInit_real_T(&st, &input_information, 1, ab_emlrtRTEI);
  input_information->canFreeData = false;
  emlrt_marshallIn(st, emlrtAlias(prhs[0]), "input_information",
                   input_information);
  sampling_frequency =
      emlrt_marshallIn(st, emlrtAliasP(prhs[1]), "sampling_frequency");
  carrier_frequency =
      emlrt_marshallIn(st, emlrtAliasP(prhs[2]), "carrier_frequency");
  freq_dev = emlrt_marshallIn(st, emlrtAliasP(prhs[3]), "freq_dev");
  // Invoke the target function
  emxInit_real_T(&st, &z, 1, ab_emlrtRTEI);
  decode(&st, input_information, sampling_frequency, carrier_frequency,
         freq_dev, z);
  emxFree_real_T(&st, &input_information);
  // Marshall function outputs
  z->canFreeData = false;
  *plhs = emlrt_marshallOut(z);
  emxFree_real_T(&st, &z);
  emlrtHeapReferenceStackLeaveFcnR2012b(&st);
}

void encode_api(const mxArray *const prhs[4], const mxArray **plhs)
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  emxArray_real_T *input_information;
  emxArray_real_T *y;
  real_T carrier_frequency;
  real_T freq_dev;
  real_T sampling_frequency;
  st.tls = emlrtRootTLSGlobal;
  emlrtHeapReferenceStackEnterFcnR2012b(&st);
  // Marshall function inputs
  emxInit_real_T(&st, &input_information, 1, ab_emlrtRTEI);
  input_information->canFreeData = false;
  emlrt_marshallIn(st, emlrtAlias(prhs[0]), "input_information",
                   input_information);
  sampling_frequency =
      emlrt_marshallIn(st, emlrtAliasP(prhs[1]), "sampling_frequency");
  carrier_frequency =
      emlrt_marshallIn(st, emlrtAliasP(prhs[2]), "carrier_frequency");
  freq_dev = emlrt_marshallIn(st, emlrtAliasP(prhs[3]), "freq_dev");
  // Invoke the target function
  emxInit_real_T(&st, &y, 1, ab_emlrtRTEI);
  encode(&st, input_information, sampling_frequency, carrier_frequency,
         freq_dev, y);
  emxFree_real_T(&st, &input_information);
  // Marshall function outputs
  y->canFreeData = false;
  *plhs = emlrt_marshallOut(y);
  emxFree_real_T(&st, &y);
  emlrtHeapReferenceStackLeaveFcnR2012b(&st);
}

// End of code generation (_coder_decode_mex_api.cpp)
