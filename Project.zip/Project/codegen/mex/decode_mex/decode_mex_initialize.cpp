//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// decode_mex_initialize.cpp
//
// Code generation for function 'decode_mex_initialize'
//

// Include files
#include "decode_mex_initialize.h"
#include "_coder_decode_mex_mex.h"
#include "decode_mex_data.h"
#include "rt_nonfinite.h"

// Function Declarations
static void decode_mex_once();

// Function Definitions
static void decode_mex_once()
{
  mex_InitInfAndNan();
}

void decode_mex_initialize()
{
  static const volatile char_T *emlrtBreakCheckR2012bFlagVar{nullptr};
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtBreakCheckR2012bFlagVar = emlrtGetBreakCheckFlagAddressR2022b(&st);
  emlrtClearAllocCountR2012b(&st, false, 0U, nullptr);
  emlrtEnterRtStackR2012b(&st);
  emlrtLicenseCheckR2022a(&st, "EMLRT:runTime:MexFunctionNeedsLicense",
                          "signal_toolbox", 2);
  if (emlrtFirstTimeR2012b(emlrtRootTLSGlobal)) {
    decode_mex_once();
  }
}

// End of code generation (decode_mex_initialize.cpp)
