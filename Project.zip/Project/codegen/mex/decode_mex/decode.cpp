//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// decode.cpp
//
// Code generation for function 'decode'
//

// Include files
#include "decode.h"
#include "decode_mex_data.h"
#include "decode_mex_emxutil.h"
#include "decode_mex_types.h"
#include "eml_int_forloop_overflow_check.h"
#include "rt_nonfinite.h"
#include "mwmathutil.h"
#include <cmath>
#include <emmintrin.h>

// Variable Definitions
static emlrtRSInfo emlrtRSI{
    2,                                                    // lineNo
    "decode",                                             // fcnName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/decode.m" // pathName
};

static emlrtRSInfo b_emlrtRSI{
    5,                                                    // lineNo
    "decode",                                             // fcnName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/decode.m" // pathName
};

static emlrtRSInfo c_emlrtRSI{
    6,                                                    // lineNo
    "decode",                                             // fcnName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/decode.m" // pathName
};

static emlrtRSInfo h_emlrtRSI{
    46,                                                        // lineNo
    "hilbert",                                                 // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/signal/signal/hilbert.m" // pathName
};

static emlrtRSInfo i_emlrtRSI{
    103,                                                       // lineNo
    "hilbert_cg",                                              // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/signal/signal/hilbert.m" // pathName
};

static emlrtRSInfo j_emlrtRSI{
    138,                                                       // lineNo
    "HilbertColumnwise",                                       // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/signal/signal/hilbert.m" // pathName
};

static emlrtRSInfo k_emlrtRSI{
    154,                                                       // lineNo
    "HilbertColumnwise",                                       // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/signal/signal/hilbert.m" // pathName
};

static emlrtRSInfo l_emlrtRSI{
    158,                                                       // lineNo
    "HilbertColumnwise",                                       // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/signal/signal/hilbert.m" // pathName
};

static emlrtRSInfo m_emlrtRSI{
    63,                                                             // lineNo
    "fft",                                                          // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/datafun/fft.m" // pathName
};

static emlrtRSInfo n_emlrtRSI{
    31,    // lineNo
    "fft", // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/eml/+coder/+internal/+fft/fft.m" // pathName
};

static emlrtRSInfo o_emlrtRSI{
    58,                // lineNo
    "executeCallback", // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/eml/+coder/+internal/+fft/fft.m" // pathName
};

static emlrtRSInfo p_emlrtRSI{
    44,                        // lineNo
    "Custom1DFFTCallback/fft", // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/shared/coder/coder/lib/+coder/+internal/"
    "Custom1DFFTCallback.m" // pathName
};

static emlrtRSInfo q_emlrtRSI{
    54,                            // lineNo
    "Custom1DFFTCallback/fftLoop", // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/shared/coder/coder/lib/+coder/+internal/"
    "Custom1DFFTCallback.m" // pathName
};

static emlrtRSInfo t_emlrtRSI{
    80,                                                              // lineNo
    "ifft",                                                          // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/datafun/ifft.m" // pathName
};

static emlrtRSInfo u_emlrtRSI{
    10,                                                           // lineNo
    "exp",                                                        // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/elfun/exp.m" // pathName
};

static emlrtRSInfo w_emlrtRSI{
    9,                                                              // lineNo
    "angle",                                                        // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/elfun/angle.m" // pathName
};

static emlrtRSInfo x_emlrtRSI{
    74,                    // lineNo
    "applyScalarFunction", // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/eml/+coder/+internal/"
    "applyScalarFunction.m" // pathName
};

static emlrtRSInfo y_emlrtRSI{
    36,                                                              // lineNo
    "unwrap",                                                        // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/elfun/unwrap.m" // pathName
};

static emlrtRSInfo ab_emlrtRSI{
    40,                                                              // lineNo
    "unwrap",                                                        // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/elfun/unwrap.m" // pathName
};

static emlrtRSInfo bb_emlrtRSI{
    43,                                                              // lineNo
    "unwrap",                                                        // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/elfun/unwrap.m" // pathName
};

static emlrtRSInfo cb_emlrtRSI{
    55,         // lineNo
    "prodsize", // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/shared/coder/coder/lib/+coder/+internal/"
    "prodsize.m" // pathName
};

static emlrtRSInfo db_emlrtRSI{
    108,                                                             // lineNo
    "diff",                                                          // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/datafun/diff.m" // pathName
};

static emlrtRSInfo eb_emlrtRSI{
    106,                                                             // lineNo
    "diff",                                                          // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/datafun/diff.m" // pathName
};

static emlrtECInfo emlrtECI{
    1,                                                    // nDims
    5,                                                    // lineNo
    10,                                                   // colNo
    "decode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/decode.m" // pName
};

static emlrtRTEInfo emlrtRTEI{
    51,                                                              // lineNo
    19,                                                              // colNo
    "diff",                                                          // fName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/datafun/diff.m" // pName
};

static emlrtECInfo b_emlrtECI{
    -1,                                                        // nDims
    103,                                                       // lineNo
    9,                                                         // colNo
    "hilbert_cg",                                              // fName
    "/usr/local/MATLAB/R2023b/toolbox/signal/signal/hilbert.m" // pName
};

static emlrtBCInfo emlrtBCI{
    -1,                                                         // iFirst
    -1,                                                         // iLast
    152,                                                        // lineNo
    20,                                                         // colNo
    "",                                                         // aName
    "HilbertColumnwise",                                        // fName
    "/usr/local/MATLAB/R2023b/toolbox/signal/signal/hilbert.m", // pName
    0                                                           // checkKind
};

static emlrtBCInfo b_emlrtBCI{
    -1,                                                         // iFirst
    -1,                                                         // iLast
    155,                                                        // lineNo
    11,                                                         // colNo
    "",                                                         // aName
    "HilbertColumnwise",                                        // fName
    "/usr/local/MATLAB/R2023b/toolbox/signal/signal/hilbert.m", // pName
    0                                                           // checkKind
};

static emlrtBCInfo
    c_emlrtBCI{
        -1,                  // iFirst
        -1,                  // iLast
        76,                  // lineNo
        9,                   // colNo
        "",                  // aName
        "eml_mtimes_helper", // fName
        "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/ops/"
        "eml_mtimes_helper.m", // pName
        0                      // checkKind
    };

static emlrtRTEInfo e_emlrtRTEI{
    2,                                                    // lineNo
    5,                                                    // colNo
    "decode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/decode.m" // pName
};

static emlrtRTEInfo i_emlrtRTEI{
    3,                                                    // lineNo
    5,                                                    // colNo
    "decode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/decode.m" // pName
};

static emlrtRTEInfo k_emlrtRTEI{
    26,                   // lineNo
    32,                   // colNo
    "MATLABFFTWCallback", // fName
    "/usr/local/MATLAB/R2023b/toolbox/eml/eml/+coder/+internal/+fft/"
    "MATLABFFTWCallback.m" // pName
};

static emlrtRTEInfo l_emlrtRTEI{
    54,                    // lineNo
    23,                    // colNo
    "Custom1DFFTCallback", // fName
    "/usr/local/MATLAB/R2023b/toolbox/shared/coder/coder/lib/+coder/+internal/"
    "Custom1DFFTCallback.m" // pName
};

static emlrtRTEInfo m_emlrtRTEI{
    26,                   // lineNo
    40,                   // colNo
    "MATLABFFTWCallback", // fName
    "/usr/local/MATLAB/R2023b/toolbox/eml/eml/+coder/+internal/+fft/"
    "MATLABFFTWCallback.m" // pName
};

static emlrtRTEInfo
    n_emlrtRTEI{
        76,                  // lineNo
        9,                   // colNo
        "eml_mtimes_helper", // fName
        "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/ops/"
        "eml_mtimes_helper.m" // pName
    };

static emlrtRTEInfo o_emlrtRTEI{
    30,                    // lineNo
    21,                    // colNo
    "applyScalarFunction", // fName
    "/usr/local/MATLAB/R2023b/toolbox/eml/eml/+coder/+internal/"
    "applyScalarFunction.m" // pName
};

static emlrtRTEInfo p_emlrtRTEI{
    30,                                                              // lineNo
    24,                                                              // colNo
    "unwrap",                                                        // fName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/elfun/unwrap.m" // pName
};

static emlrtRTEInfo q_emlrtRTEI{
    78,                                                              // lineNo
    21,                                                              // colNo
    "diff",                                                          // fName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/datafun/diff.m" // pName
};

static emlrtRTEInfo r_emlrtRTEI{
    6,                                                    // lineNo
    5,                                                    // colNo
    "decode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/decode.m" // pName
};

static emlrtRTEInfo s_emlrtRTEI{
    5,                                                    // lineNo
    5,                                                    // colNo
    "decode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/decode.m" // pName
};

static emlrtRTEInfo t_emlrtRTEI{
    2,                                                    // lineNo
    10,                                                   // colNo
    "decode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/decode.m" // pName
};

static emlrtRTEInfo u_emlrtRTEI{
    6,                                                    // lineNo
    73,                                                   // colNo
    "decode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/decode.m" // pName
};

static emlrtRTEInfo bb_emlrtRTEI{
    5,                                                    // lineNo
    10,                                                   // colNo
    "decode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/decode.m" // pName
};

// Function Declarations
static void times(const emlrtStack &sp, emxArray_creal_T *in1,
                  const emxArray_creal_T *in2);

// Function Definitions
static void times(const emlrtStack &sp, emxArray_creal_T *in1,
                  const emxArray_creal_T *in2)
{
  emxArray_creal_T *b_in1;
  const creal_T *in2_data;
  creal_T *b_in1_data;
  creal_T *in1_data;
  int32_T i;
  int32_T loop_ub;
  int32_T stride_0_0;
  int32_T stride_1_0;
  in2_data = in2->data;
  in1_data = in1->data;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  emxInit_creal_T(sp, &b_in1, bb_emlrtRTEI);
  if (in2->size[0] == 1) {
    loop_ub = in1->size[0];
  } else {
    loop_ub = in2->size[0];
  }
  i = b_in1->size[0];
  b_in1->size[0] = loop_ub;
  emxEnsureCapacity_creal_T(&sp, b_in1, i, bb_emlrtRTEI);
  b_in1_data = b_in1->data;
  stride_0_0 = (in1->size[0] != 1);
  stride_1_0 = (in2->size[0] != 1);
  for (i = 0; i < loop_ub; i++) {
    real_T d;
    real_T d1;
    real_T d2;
    real_T d3;
    int32_T i1;
    int32_T i2;
    i1 = i * stride_0_0;
    d = in1_data[i1].re;
    i2 = i * stride_1_0;
    d1 = in2_data[i2].im;
    d2 = in1_data[i1].im;
    d3 = in2_data[i2].re;
    b_in1_data[i].re = d * d3 - d2 * d1;
    b_in1_data[i].im = d * d1 + d2 * d3;
  }
  i = in1->size[0];
  in1->size[0] = b_in1->size[0];
  emxEnsureCapacity_creal_T(&sp, in1, i, bb_emlrtRTEI);
  in1_data = in1->data;
  loop_ub = b_in1->size[0];
  for (i = 0; i < loop_ub; i++) {
    in1_data[i] = b_in1_data[i];
  }
  emxFree_creal_T(&sp, &b_in1);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

void decode(const emlrtStack *sp, const emxArray_real_T *input_information,
            real_T sampling_frequency, real_T carrier_frequency,
            real_T freq_dev, emxArray_real_T *z)
{
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack h_st;
  emlrtStack i_st;
  emlrtStack st;
  emxArray_creal_T *x;
  emxArray_creal_T *yq;
  emxArray_real_T *b_y;
  emxArray_real_T *t;
  emxArray_real_T *y;
  creal_T *x_data;
  creal_T *yq_data;
  const real_T *input_information_data;
  real_T cdiff;
  real_T dp;
  real_T kd;
  real_T ndbl;
  real_T *t_data;
  real_T *z_data;
  int32_T firstIndexToZero;
  int32_T halfn;
  int32_T lastIndexToDouble;
  int32_T m;
  int32_T nm1d2;
  int32_T vlen;
  uint32_T ySize_idx_0;
  boolean_T overflow;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  h_st.prev = &g_st;
  h_st.tls = g_st.tls;
  i_st.prev = &h_st;
  i_st.tls = h_st.tls;
  input_information_data = input_information->data;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)sp);
  emxInit_real_T(sp, &t, 1, e_emlrtRTEI);
  emxInit_real_T(sp, &y, 2, t_emlrtRTEI);
  z_data = y->data;
  st.site = &emlrtRSI;
  dp = 1.0 / sampling_frequency;
  kd = (static_cast<real_T>(input_information->size[0]) - 1.0) /
       sampling_frequency;
  if (muDoubleScalarIsNaN(dp) || muDoubleScalarIsNaN(kd)) {
    firstIndexToZero = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 1;
    emxEnsureCapacity_real_T(&st, y, firstIndexToZero, &d_emlrtRTEI);
    z_data = y->data;
    z_data[0] = rtNaN;
  } else if ((dp == 0.0) || ((kd > 0.0) && (dp < 0.0)) ||
             ((kd < 0.0) && (dp > 0.0))) {
    y->size[0] = 1;
    y->size[1] = 0;
  } else if (muDoubleScalarIsInf(kd) && muDoubleScalarIsInf(dp)) {
    firstIndexToZero = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 1;
    emxEnsureCapacity_real_T(&st, y, firstIndexToZero, &f_emlrtRTEI);
    z_data = y->data;
    z_data[0] = rtNaN;
  } else if (muDoubleScalarIsInf(dp)) {
    firstIndexToZero = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 1;
    emxEnsureCapacity_real_T(&st, y, firstIndexToZero, &g_emlrtRTEI);
    z_data = y->data;
    z_data[0] = 0.0;
  } else if (muDoubleScalarFloor(dp) == dp) {
    firstIndexToZero = y->size[0] * y->size[1];
    y->size[0] = 1;
    lastIndexToDouble = static_cast<int32_T>(kd / dp);
    y->size[1] = lastIndexToDouble + 1;
    emxEnsureCapacity_real_T(&st, y, firstIndexToZero, &h_emlrtRTEI);
    z_data = y->data;
    for (firstIndexToZero = 0; firstIndexToZero <= lastIndexToDouble;
         firstIndexToZero++) {
      z_data[firstIndexToZero] = dp * static_cast<real_T>(firstIndexToZero);
    }
  } else {
    real_T apnd;
    b_st.site = &d_emlrtRSI;
    ndbl = muDoubleScalarFloor(kd / dp + 0.5);
    apnd = ndbl * dp;
    if (dp > 0.0) {
      cdiff = apnd - kd;
    } else {
      cdiff = kd - apnd;
    }
    if (muDoubleScalarAbs(cdiff) <
        4.4408920985006262E-16 * muDoubleScalarAbs(kd)) {
      ndbl++;
      apnd = kd;
    } else if (cdiff > 0.0) {
      apnd = (ndbl - 1.0) * dp;
    } else {
      ndbl++;
    }
    if (ndbl >= 0.0) {
      halfn = static_cast<int32_T>(ndbl);
    } else {
      halfn = 0;
    }
    c_st.site = &e_emlrtRSI;
    if (ndbl > 2.147483647E+9) {
      emlrtErrorWithMessageIdR2018a(&c_st, &b_emlrtRTEI,
                                    "Coder:MATLAB:pmaxsize",
                                    "Coder:MATLAB:pmaxsize", 0);
    }
    firstIndexToZero = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = halfn;
    emxEnsureCapacity_real_T(&b_st, y, firstIndexToZero, &j_emlrtRTEI);
    z_data = y->data;
    if (halfn > 0) {
      z_data[0] = 0.0;
      if (halfn > 1) {
        z_data[halfn - 1] = apnd;
        nm1d2 = (halfn - 1) / 2;
        c_st.site = &f_emlrtRSI;
        for (m = 0; m <= nm1d2 - 2; m++) {
          kd = (static_cast<real_T>(m) + 1.0) * dp;
          z_data[m + 1] = kd;
          z_data[(halfn - m) - 2] = apnd - kd;
        }
        if (nm1d2 << 1 == halfn - 1) {
          z_data[nm1d2] = apnd / 2.0;
        } else {
          kd = static_cast<real_T>(nm1d2) * dp;
          z_data[nm1d2] = kd;
          z_data[nm1d2 + 1] = apnd - kd;
        }
      }
    }
  }
  firstIndexToZero = t->size[0];
  t->size[0] = y->size[1];
  emxEnsureCapacity_real_T(sp, t, firstIndexToZero, &e_emlrtRTEI);
  t_data = t->data;
  lastIndexToDouble = y->size[1];
  for (firstIndexToZero = 0; firstIndexToZero < lastIndexToDouble;
       firstIndexToZero++) {
    t_data[firstIndexToZero] = z_data[firstIndexToZero];
  }
  emxFree_real_T(sp, &y);
  nm1d2 = t->size[0];
  firstIndexToZero = t->size[0];
  t->size[0] = nm1d2;
  emxEnsureCapacity_real_T(sp, t, firstIndexToZero, &i_emlrtRTEI);
  t_data = t->data;
  st.site = &b_emlrtRSI;
  b_st.site = &h_emlrtRSI;
  c_st.site = &i_emlrtRSI;
  d_st.site = &j_emlrtRSI;
  e_st.site = &m_emlrtRSI;
  emxInit_creal_T(e_st, &yq, s_emlrtRTEI);
  yq_data = yq->data;
  if (input_information->size[0] == 0) {
    yq->size[0] = 0;
  } else {
    f_st.site = &n_emlrtRSI;
    g_st.site = &o_emlrtRSI;
    h_st.site = &p_emlrtRSI;
    i_st.site = &q_emlrtRSI;
    emlrtFFTWSetNumThreads(2);
    firstIndexToZero = yq->size[0];
    yq->size[0] = input_information->size[0];
    emxEnsureCapacity_creal_T(&i_st, yq, firstIndexToZero, k_emlrtRTEI);
    yq_data = yq->data;
    emlrtFFTW_1D_R2C((real_T *)&input_information_data[0],
                     (real_T *)&yq_data[0], 1, input_information->size[0],
                     input_information->size[0], 1, -1);
  }
  nm1d2 = input_information->size[0];
  halfn = input_information->size[0] >> 1;
  if ((input_information->size[0] & 1) == 0) {
    lastIndexToDouble = halfn;
  } else {
    lastIndexToDouble = halfn + 1;
  }
  firstIndexToZero = halfn + 2;
  for (int32_T i{2}; i <= lastIndexToDouble; i++) {
    if (i > yq->size[0]) {
      emlrtDynamicBoundsCheckR2012b(i, 1, yq->size[0], &emlrtBCI, &c_st);
    }
    yq_data[i - 1].re *= 2.0;
    if (i > yq->size[0]) {
      emlrtDynamicBoundsCheckR2012b(i, 1, yq->size[0], &c_emlrtBCI, &c_st);
    }
    yq_data[i - 1].im *= 2.0;
  }
  d_st.site = &k_emlrtRSI;
  if ((halfn + 2 <= input_information->size[0]) &&
      (input_information->size[0] > 2147483646)) {
    e_st.site = &g_emlrtRSI;
    coder::check_forloop_overflow_error(e_st);
  }
  for (int32_T i{firstIndexToZero}; i <= nm1d2; i++) {
    if (i > yq->size[0]) {
      emlrtDynamicBoundsCheckR2012b(i, 1, yq->size[0], &b_emlrtBCI, &c_st);
    }
    yq_data[i - 1].re = 0.0;
    if (i > yq->size[0]) {
      emlrtDynamicBoundsCheckR2012b(i, 1, yq->size[0], &b_emlrtBCI, &c_st);
    }
    yq_data[i - 1].im = 0.0;
  }
  d_st.site = &l_emlrtRSI;
  nm1d2 = yq->size[0];
  e_st.site = &t_emlrtRSI;
  emxInit_creal_T(e_st, &x, l_emlrtRTEI);
  if (yq->size[0] == 0) {
    yq->size[0] = 0;
  } else {
    f_st.site = &n_emlrtRSI;
    g_st.site = &o_emlrtRSI;
    h_st.site = &p_emlrtRSI;
    i_st.site = &q_emlrtRSI;
    firstIndexToZero = x->size[0];
    x->size[0] = yq->size[0];
    emxEnsureCapacity_creal_T(&i_st, x, firstIndexToZero, l_emlrtRTEI);
    x_data = x->data;
    lastIndexToDouble = yq->size[0];
    for (firstIndexToZero = 0; firstIndexToZero < lastIndexToDouble;
         firstIndexToZero++) {
      x_data[firstIndexToZero] = yq_data[firstIndexToZero];
    }
    emlrtFFTWSetNumThreads(2);
    ySize_idx_0 = static_cast<uint32_T>(yq->size[0]);
    firstIndexToZero = yq->size[0];
    yq->size[0] = static_cast<int32_T>(ySize_idx_0);
    emxEnsureCapacity_creal_T(&i_st, yq, firstIndexToZero, m_emlrtRTEI);
    yq_data = yq->data;
    emlrtFFTW_1D_C2C((real_T *)&x_data[0], (real_T *)&yq_data[0], 1, nm1d2,
                     x->size[0], 1, 1);
  }
  if (input_information->size[0] != yq->size[0]) {
    emlrtSubAssignSizeCheck1dR2017a(input_information->size[0], yq->size[0],
                                    &b_emlrtECI, &b_st);
  }
  kd = carrier_frequency * -0.0;
  dp = carrier_frequency * -6.2831853071795862;
  firstIndexToZero = x->size[0];
  x->size[0] = t->size[0];
  emxEnsureCapacity_creal_T(sp, x, firstIndexToZero, n_emlrtRTEI);
  x_data = x->data;
  lastIndexToDouble = t->size[0];
  for (firstIndexToZero = 0; firstIndexToZero < lastIndexToDouble;
       firstIndexToZero++) {
    x_data[firstIndexToZero].re = t_data[firstIndexToZero] * kd;
    x_data[firstIndexToZero].im = t_data[firstIndexToZero] * dp;
  }
  st.site = &b_emlrtRSI;
  b_st.site = &u_emlrtRSI;
  nm1d2 = x->size[0];
  c_st.site = &v_emlrtRSI;
  if (x->size[0] > 2147483646) {
    d_st.site = &g_emlrtRSI;
    coder::check_forloop_overflow_error(d_st);
  }
  for (m = 0; m < nm1d2; m++) {
    if (x_data[m].re == 0.0) {
      dp = x_data[m].im;
      x_data[m].re = muDoubleScalarCos(dp);
      x_data[m].im = muDoubleScalarSin(dp);
    } else if (x_data[m].im == 0.0) {
      x_data[m].re = muDoubleScalarExp(x_data[m].re);
      x_data[m].im = 0.0;
    } else if (muDoubleScalarIsInf(x_data[m].im) &&
               muDoubleScalarIsInf(x_data[m].re) && (x_data[m].re < 0.0)) {
      x_data[m].re = 0.0;
      x_data[m].im = 0.0;
    } else {
      kd = muDoubleScalarExp(x_data[m].re / 2.0);
      dp = x_data[m].im;
      x_data[m].re = kd * (kd * muDoubleScalarCos(dp));
      x_data[m].im = kd * (kd * muDoubleScalarSin(dp));
    }
  }
  if ((yq->size[0] != x->size[0]) &&
      ((yq->size[0] != 1) && (x->size[0] != 1))) {
    emlrtDimSizeImpxCheckR2021b(yq->size[0], x->size[0], &emlrtECI,
                                (emlrtConstCTX)sp);
  }
  if (yq->size[0] == x->size[0]) {
    lastIndexToDouble = yq->size[0];
    for (firstIndexToZero = 0; firstIndexToZero < lastIndexToDouble;
         firstIndexToZero++) {
      dp = yq_data[firstIndexToZero].re;
      kd = x_data[firstIndexToZero].im;
      ndbl = yq_data[firstIndexToZero].im;
      cdiff = x_data[firstIndexToZero].re;
      yq_data[firstIndexToZero].re = dp * cdiff - ndbl * kd;
      yq_data[firstIndexToZero].im = dp * kd + ndbl * cdiff;
    }
  } else {
    st.site = &b_emlrtRSI;
    times(st, yq, x);
    yq_data = yq->data;
  }
  emxFree_creal_T(sp, &x);
  emxInit_real_T(sp, &b_y, 1, u_emlrtRTEI);
  st.site = &c_emlrtRSI;
  b_st.site = &w_emlrtRSI;
  nm1d2 = yq->size[0];
  firstIndexToZero = b_y->size[0];
  b_y->size[0] = yq->size[0];
  emxEnsureCapacity_real_T(&b_st, b_y, firstIndexToZero, &o_emlrtRTEI);
  z_data = b_y->data;
  c_st.site = &x_emlrtRSI;
  if (yq->size[0] > 2147483646) {
    d_st.site = &g_emlrtRSI;
    coder::check_forloop_overflow_error(d_st);
  }
  for (m = 0; m < nm1d2; m++) {
    z_data[m] = muDoubleScalarAtan2(yq_data[m].im, yq_data[m].re);
  }
  emxFree_creal_T(&b_st, &yq);
  st.site = &c_emlrtRSI;
  nm1d2 = 0;
  if (b_y->size[0] != 1) {
    nm1d2 = -1;
  }
  if (nm1d2 + 2 <= 1) {
    vlen = b_y->size[0] - 1;
  } else {
    vlen = 0;
  }
  firstIndexToZero = t->size[0];
  t->size[0] = vlen + 1;
  emxEnsureCapacity_real_T(&st, t, firstIndexToZero, &p_emlrtRTEI);
  t_data = t->data;
  b_st.site = &y_emlrtRSI;
  firstIndexToZero = 1;
  c_st.site = &cb_emlrtRSI;
  for (m = 0; m <= nm1d2; m++) {
    firstIndexToZero *= b_y->size[0];
  }
  nm1d2 = vlen * firstIndexToZero;
  halfn = 0;
  b_st.site = &ab_emlrtRSI;
  overflow = (firstIndexToZero > 2147483646);
  for (int32_T i{0}; i < 1; i++) {
    lastIndexToDouble = halfn - 1;
    halfn += nm1d2;
    b_st.site = &bb_emlrtRSI;
    if (overflow) {
      c_st.site = &g_emlrtRSI;
      coder::check_forloop_overflow_error(c_st);
    }
    for (int32_T j{0}; j < firstIndexToZero; j++) {
      boolean_T exitg1;
      lastIndexToDouble++;
      halfn++;
      for (m = 0; m <= vlen; m++) {
        t_data[m] = z_data[lastIndexToDouble + m * firstIndexToZero];
      }
      m = t->size[0];
      cdiff = 0.0;
      ySize_idx_0 = 1U;
      exitg1 = false;
      while ((!exitg1) && (static_cast<int32_T>(ySize_idx_0) < m)) {
        dp = t_data[static_cast<int32_T>(ySize_idx_0) - 1];
        if (muDoubleScalarIsInf(dp) || muDoubleScalarIsNaN(dp)) {
          ySize_idx_0 =
              static_cast<uint32_T>(static_cast<int32_T>(ySize_idx_0) + 1);
        } else {
          exitg1 = true;
        }
      }
      if (static_cast<int32_T>(ySize_idx_0) < t->size[0]) {
        kd = t_data[static_cast<int32_T>(ySize_idx_0) - 1];
        int32_T exitg2;
        do {
          exitg2 = 0;
          ySize_idx_0++;
          exitg1 = false;
          while ((!exitg1) && (ySize_idx_0 <= static_cast<uint32_T>(m))) {
            dp = t_data[static_cast<int32_T>(ySize_idx_0) - 1];
            if (muDoubleScalarIsInf(dp) || muDoubleScalarIsNaN(dp)) {
              ySize_idx_0++;
            } else {
              exitg1 = true;
            }
          }
          if (ySize_idx_0 > static_cast<uint32_T>(m)) {
            exitg2 = 1;
          } else {
            ndbl = t_data[static_cast<int32_T>(ySize_idx_0) - 1];
            dp = ndbl - kd;
            kd = dp / 6.2831853071795862;
            if (muDoubleScalarAbs(muDoubleScalarRem(kd, 1.0)) <= 0.5) {
              kd = std::trunc(kd);
            } else {
              kd = muDoubleScalarRound(kd);
            }
            if (muDoubleScalarAbs(dp) >= 3.1415926535897931) {
              cdiff += kd;
            }
            kd = ndbl;
            t_data[static_cast<int32_T>(ySize_idx_0) - 1] =
                ndbl - 6.2831853071795862 * cdiff;
          }
        } while (exitg2 == 0);
      }
      for (m = 0; m <= vlen; m++) {
        z_data[lastIndexToDouble + m * firstIndexToZero] = t_data[m];
      }
    }
  }
  st.site = &c_emlrtRSI;
  nm1d2 = b_y->size[0];
  if (b_y->size[0] == 0) {
    t->size[0] = 0;
  } else {
    halfn = b_y->size[0] - 1;
    if (muIntScalarMin_sint32(halfn, 1) < 1) {
      t->size[0] = 0;
    } else {
      if (b_y->size[0] == 1) {
        emlrtErrorWithMessageIdR2018a(
            &st, &emlrtRTEI, "Coder:toolbox:autoDimIncompatibility",
            "Coder:toolbox:autoDimIncompatibility", 0);
      }
      firstIndexToZero = t->size[0];
      t->size[0] = b_y->size[0] - 1;
      emxEnsureCapacity_real_T(&st, t, firstIndexToZero, &q_emlrtRTEI);
      t_data = t->data;
      dp = z_data[0];
      b_st.site = &eb_emlrtRSI;
      if (b_y->size[0] > 2147483646) {
        c_st.site = &g_emlrtRSI;
        coder::check_forloop_overflow_error(c_st);
      }
      for (m = 2; m <= nm1d2; m++) {
        b_st.site = &db_emlrtRSI;
        kd = dp;
        dp = z_data[m - 1];
        t_data[m - 2] = dp - kd;
      }
    }
  }
  emxFree_real_T(&st, &b_y);
  kd = 1.0 / (6.2831853071795862 * freq_dev);
  firstIndexToZero = z->size[0];
  z->size[0] = t->size[0] + 1;
  emxEnsureCapacity_real_T(sp, z, firstIndexToZero, &r_emlrtRTEI);
  z_data = z->data;
  z_data[0] = kd * 0.0;
  lastIndexToDouble = t->size[0];
  nm1d2 = (lastIndexToDouble / 2) << 1;
  halfn = nm1d2 - 2;
  for (firstIndexToZero = 0; firstIndexToZero <= halfn; firstIndexToZero += 2) {
    __m128d r;
    r = _mm_loadu_pd(&t_data[firstIndexToZero]);
    _mm_storeu_pd(&z_data[firstIndexToZero + 1],
                  _mm_mul_pd(_mm_set1_pd(kd),
                             _mm_mul_pd(r, _mm_set1_pd(sampling_frequency))));
  }
  for (firstIndexToZero = nm1d2; firstIndexToZero < lastIndexToDouble;
       firstIndexToZero++) {
    z_data[firstIndexToZero + 1] =
        kd * (t_data[firstIndexToZero] * sampling_frequency);
  }
  emxFree_real_T(sp, &t);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)sp);
}

// End of code generation (decode.cpp)
