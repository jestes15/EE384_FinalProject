//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// decode_mex_data.cpp
//
// Code generation for function 'decode_mex_data'
//

// Include files
#include "decode_mex_data.h"
#include "rt_nonfinite.h"

// Variable Definitions
emlrtCTX emlrtRootTLSGlobal{nullptr};

emlrtContext emlrtContextGlobal{
    true,                                                // bFirstTime
    false,                                               // bInitialized
    131643U,                                             // fVersionInfo
    nullptr,                                             // fErrorFunction
    "decode_mex",                                        // fFunctionName
    nullptr,                                             // fRTCallStack
    false,                                               // bDebugMode
    {497312255U, 2566552405U, 2553285182U, 2715458501U}, // fSigWrd
    nullptr                                              // fSigMem
};

emlrtRSInfo d_emlrtRSI{
    125,                                                          // lineNo
    "colon",                                                      // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/ops/colon.m" // pathName
};

emlrtRSInfo e_emlrtRSI{
    319,                                                          // lineNo
    "eml_float_colon",                                            // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/ops/colon.m" // pathName
};

emlrtRSInfo f_emlrtRSI{
    328,                                                          // lineNo
    "eml_float_colon",                                            // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/ops/colon.m" // pathName
};

emlrtRSInfo g_emlrtRSI{
    20,                               // lineNo
    "eml_int_forloop_overflow_check", // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/eml/"
    "eml_int_forloop_overflow_check.m" // pathName
};

emlrtRSInfo v_emlrtRSI{
    33,                           // lineNo
    "applyScalarFunctionInPlace", // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/eml/+coder/+internal/"
    "applyScalarFunctionInPlace.m" // pathName
};

emlrtRTEInfo b_emlrtRTEI{
    419,                                                          // lineNo
    15,                                                           // colNo
    "assert_pmaxsize",                                            // fName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/ops/colon.m" // pName
};

emlrtRTEInfo d_emlrtRTEI{
    84,                                                           // lineNo
    5,                                                            // colNo
    "colon",                                                      // fName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/ops/colon.m" // pName
};

emlrtRTEInfo f_emlrtRTEI{
    96,                                                           // lineNo
    5,                                                            // colNo
    "colon",                                                      // fName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/ops/colon.m" // pName
};

emlrtRTEInfo g_emlrtRTEI{
    98,                                                           // lineNo
    5,                                                            // colNo
    "colon",                                                      // fName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/ops/colon.m" // pName
};

emlrtRTEInfo h_emlrtRTEI{
    113,                                                          // lineNo
    9,                                                            // colNo
    "colon",                                                      // fName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/ops/colon.m" // pName
};

emlrtRTEInfo j_emlrtRTEI{
    320,                                                          // lineNo
    20,                                                           // colNo
    "colon",                                                      // fName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/ops/colon.m" // pName
};

// End of code generation (decode_mex_data.cpp)
