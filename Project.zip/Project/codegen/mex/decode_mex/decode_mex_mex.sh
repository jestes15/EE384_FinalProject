"/usr/local/MATLAB/R2023b/toolbox/shared/coder/ninja/glnxa64/ninja" -t compdb cc cxx cudac > compile_commands.json
"/usr/local/MATLAB/R2023b/toolbox/shared/coder/ninja/glnxa64/ninja" -v "$@"
