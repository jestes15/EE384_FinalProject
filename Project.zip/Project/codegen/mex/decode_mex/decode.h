//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// decode.h
//
// Code generation for function 'decode'
//

#pragma once

// Include files
#include "decode_mex_types.h"
#include "rtwtypes.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

// Function Declarations
void decode(const emlrtStack *sp, const emxArray_real_T *input_information,
            real_T sampling_frequency, real_T carrier_frequency,
            real_T freq_dev, emxArray_real_T *z);

// End of code generation (decode.h)
