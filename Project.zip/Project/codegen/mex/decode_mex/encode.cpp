//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// encode.cpp
//
// Code generation for function 'encode'
//

// Include files
#include "encode.h"
#include "decode_mex_data.h"
#include "decode_mex_emxutil.h"
#include "decode_mex_types.h"
#include "eml_int_forloop_overflow_check.h"
#include "rt_nonfinite.h"
#include "mwmathutil.h"
#include <emmintrin.h>

// Variable Definitions
static emlrtRSInfo fb_emlrtRSI{
    2,                                                    // lineNo
    "encode",                                             // fcnName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/encode.m" // pathName
};

static emlrtRSInfo gb_emlrtRSI{
    5,                                                    // lineNo
    "encode",                                             // fcnName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/encode.m" // pathName
};

static emlrtRSInfo hb_emlrtRSI{
    7,                                                    // lineNo
    "encode",                                             // fcnName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/encode.m" // pathName
};

static emlrtRSInfo ib_emlrtRSI{
    14,       // lineNo
    "cumsum", // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/datafun/cumsum.m" // pathName
};

static emlrtRSInfo
    jb_emlrtRSI{
        16,      // lineNo
        "cumop", // fcnName
        "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/datafun/private/"
        "cumop.m" // pathName
    };

static emlrtRSInfo ob_emlrtRSI{
    11,                                                           // lineNo
    "cos",                                                        // fcnName
    "/usr/local/MATLAB/R2023b/toolbox/eml/lib/matlab/elfun/cos.m" // pathName
};

static emlrtECInfo c_emlrtECI{
    1,                                                    // nDims
    7,                                                    // lineNo
    13,                                                   // colNo
    "encode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/encode.m" // pName
};

static emlrtRTEInfo v_emlrtRTEI{
    2,                                                    // lineNo
    5,                                                    // colNo
    "encode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/encode.m" // pName
};

static emlrtRTEInfo w_emlrtRTEI{
    3,                                                    // lineNo
    5,                                                    // colNo
    "encode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/encode.m" // pName
};

static emlrtRTEInfo x_emlrtRTEI{
    5,                                                    // lineNo
    20,                                                   // colNo
    "encode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/encode.m" // pName
};

static emlrtRTEInfo y_emlrtRTEI{
    2,                                                    // lineNo
    10,                                                   // colNo
    "encode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/encode.m" // pName
};

static emlrtRTEInfo cb_emlrtRTEI{
    7,                                                    // lineNo
    13,                                                   // colNo
    "encode",                                             // fName
    "/home/bl4z3/Documents/MATLAB/EE315/Project/encode.m" // pName
};

// Function Declarations
static void plus(const emlrtStack &sp, emxArray_real_T *in1,
                 const emxArray_real_T *in2);

// Function Definitions
static void plus(const emlrtStack &sp, emxArray_real_T *in1,
                 const emxArray_real_T *in2)
{
  emxArray_real_T *b_in1;
  const real_T *in2_data;
  real_T *b_in1_data;
  real_T *in1_data;
  int32_T i;
  int32_T loop_ub;
  int32_T stride_0_0;
  int32_T stride_1_0;
  in2_data = in2->data;
  in1_data = in1->data;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  emxInit_real_T(&sp, &b_in1, 1, cb_emlrtRTEI);
  if (in2->size[0] == 1) {
    loop_ub = in1->size[0];
  } else {
    loop_ub = in2->size[0];
  }
  i = b_in1->size[0];
  b_in1->size[0] = loop_ub;
  emxEnsureCapacity_real_T(&sp, b_in1, i, &cb_emlrtRTEI);
  b_in1_data = b_in1->data;
  stride_0_0 = (in1->size[0] != 1);
  stride_1_0 = (in2->size[0] != 1);
  for (i = 0; i < loop_ub; i++) {
    b_in1_data[i] = in1_data[i * stride_0_0] + in2_data[i * stride_1_0];
  }
  i = in1->size[0];
  in1->size[0] = b_in1->size[0];
  emxEnsureCapacity_real_T(&sp, in1, i, &cb_emlrtRTEI);
  in1_data = in1->data;
  loop_ub = b_in1->size[0];
  for (i = 0; i < loop_ub; i++) {
    in1_data[i] = b_in1_data[i];
  }
  emxFree_real_T(&sp, &b_in1);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

void encode(const emlrtStack *sp, const emxArray_real_T *input_information,
            real_T sampling_frequency, real_T carrier_frequency,
            real_T freq_dev, emxArray_real_T *y)
{
  __m128d r;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack st;
  emxArray_real_T *b_y;
  emxArray_real_T *x;
  const real_T *input_information_data;
  real_T d;
  real_T kd;
  real_T *b_y_data;
  real_T *y_data;
  int32_T i;
  int32_T k;
  int32_T n;
  int32_T nm1d2;
  boolean_T overflow;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  input_information_data = input_information->data;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)sp);
  emxInit_real_T(sp, &b_y, 2, y_emlrtRTEI);
  y_data = b_y->data;
  emxInit_real_T(sp, &x, 1, x_emlrtRTEI);
  st.site = &fb_emlrtRSI;
  d = 1.0 / sampling_frequency;
  kd = (static_cast<real_T>(input_information->size[0]) - 1.0) /
       sampling_frequency;
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsNaN(kd)) {
    i = b_y->size[0] * b_y->size[1];
    b_y->size[0] = 1;
    b_y->size[1] = 1;
    emxEnsureCapacity_real_T(&st, b_y, i, &d_emlrtRTEI);
    y_data = b_y->data;
    y_data[0] = rtNaN;
  } else if ((d == 0.0) || ((kd > 0.0) && (d < 0.0)) ||
             ((kd < 0.0) && (d > 0.0))) {
    b_y->size[0] = 1;
    b_y->size[1] = 0;
  } else if (muDoubleScalarIsInf(kd) && muDoubleScalarIsInf(d)) {
    i = b_y->size[0] * b_y->size[1];
    b_y->size[0] = 1;
    b_y->size[1] = 1;
    emxEnsureCapacity_real_T(&st, b_y, i, &f_emlrtRTEI);
    y_data = b_y->data;
    y_data[0] = rtNaN;
  } else if (muDoubleScalarIsInf(d)) {
    i = b_y->size[0] * b_y->size[1];
    b_y->size[0] = 1;
    b_y->size[1] = 1;
    emxEnsureCapacity_real_T(&st, b_y, i, &g_emlrtRTEI);
    y_data = b_y->data;
    y_data[0] = 0.0;
  } else if (muDoubleScalarFloor(d) == d) {
    i = b_y->size[0] * b_y->size[1];
    b_y->size[0] = 1;
    nm1d2 = static_cast<int32_T>(kd / d);
    b_y->size[1] = nm1d2 + 1;
    emxEnsureCapacity_real_T(&st, b_y, i, &h_emlrtRTEI);
    y_data = b_y->data;
    for (i = 0; i <= nm1d2; i++) {
      y_data[i] = d * static_cast<real_T>(i);
    }
  } else {
    real_T apnd;
    real_T cdiff;
    real_T ndbl;
    b_st.site = &d_emlrtRSI;
    ndbl = muDoubleScalarFloor(kd / d + 0.5);
    apnd = ndbl * d;
    if (d > 0.0) {
      cdiff = apnd - kd;
    } else {
      cdiff = kd - apnd;
    }
    if (muDoubleScalarAbs(cdiff) <
        4.4408920985006262E-16 * muDoubleScalarAbs(kd)) {
      ndbl++;
      apnd = kd;
    } else if (cdiff > 0.0) {
      apnd = (ndbl - 1.0) * d;
    } else {
      ndbl++;
    }
    if (ndbl >= 0.0) {
      n = static_cast<int32_T>(ndbl);
    } else {
      n = 0;
    }
    c_st.site = &e_emlrtRSI;
    if (ndbl > 2.147483647E+9) {
      emlrtErrorWithMessageIdR2018a(&c_st, &b_emlrtRTEI,
                                    "Coder:MATLAB:pmaxsize",
                                    "Coder:MATLAB:pmaxsize", 0);
    }
    i = b_y->size[0] * b_y->size[1];
    b_y->size[0] = 1;
    b_y->size[1] = n;
    emxEnsureCapacity_real_T(&b_st, b_y, i, &j_emlrtRTEI);
    y_data = b_y->data;
    if (n > 0) {
      y_data[0] = 0.0;
      if (n > 1) {
        y_data[n - 1] = apnd;
        nm1d2 = (n - 1) / 2;
        c_st.site = &f_emlrtRSI;
        for (k = 0; k <= nm1d2 - 2; k++) {
          kd = (static_cast<real_T>(k) + 1.0) * d;
          y_data[k + 1] = kd;
          y_data[(n - k) - 2] = apnd - kd;
        }
        if (nm1d2 << 1 == n - 1) {
          y_data[nm1d2] = apnd / 2.0;
        } else {
          kd = static_cast<real_T>(nm1d2) * d;
          y_data[nm1d2] = kd;
          y_data[nm1d2 + 1] = apnd - kd;
        }
      }
    }
  }
  i = y->size[0];
  y->size[0] = b_y->size[1];
  emxEnsureCapacity_real_T(sp, y, i, &v_emlrtRTEI);
  b_y_data = y->data;
  nm1d2 = b_y->size[1];
  for (i = 0; i < nm1d2; i++) {
    b_y_data[i] = y_data[i];
  }
  emxFree_real_T(sp, &b_y);
  nm1d2 = y->size[0];
  i = y->size[0];
  y->size[0] = nm1d2;
  emxEnsureCapacity_real_T(sp, y, i, &w_emlrtRTEI);
  b_y_data = y->data;
  st.site = &gb_emlrtRSI;
  i = x->size[0];
  x->size[0] = input_information->size[0];
  emxEnsureCapacity_real_T(&st, x, i, &x_emlrtRTEI);
  y_data = x->data;
  nm1d2 = input_information->size[0];
  for (i = 0; i < nm1d2; i++) {
    y_data[i] = input_information_data[i];
  }
  b_st.site = &ib_emlrtRSI;
  nm1d2 = 2;
  if (input_information->size[0] != 1) {
    nm1d2 = 1;
  }
  c_st.site = &jb_emlrtRSI;
  if ((nm1d2 == 1) && (input_information->size[0] != 0) &&
      (input_information->size[0] != 1)) {
    i = input_information->size[0];
    for (k = 0; k <= i - 2; k++) {
      y_data[k + 1] += y_data[k];
    }
  }
  kd = 6.2831853071795862 * carrier_frequency;
  nm1d2 = y->size[0];
  n = (nm1d2 / 2) << 1;
  k = n - 2;
  for (i = 0; i <= k; i += 2) {
    r = _mm_loadu_pd(&b_y_data[i]);
    _mm_storeu_pd(&b_y_data[i], _mm_mul_pd(_mm_set1_pd(kd), r));
  }
  for (i = n; i < nm1d2; i++) {
    b_y_data[i] *= kd;
  }
  kd = 6.2831853071795862 * freq_dev;
  nm1d2 = x->size[0];
  n = (nm1d2 / 2) << 1;
  k = n - 2;
  for (i = 0; i <= k; i += 2) {
    r = _mm_loadu_pd(&y_data[i]);
    _mm_storeu_pd(&y_data[i],
                  _mm_mul_pd(_mm_set1_pd(kd),
                             _mm_div_pd(r, _mm_set1_pd(sampling_frequency))));
  }
  for (i = n; i < nm1d2; i++) {
    y_data[i] = kd * (y_data[i] / sampling_frequency);
  }
  i = y->size[0];
  nm1d2 = x->size[0];
  if ((i != nm1d2) && ((i != 1) && (nm1d2 != 1))) {
    emlrtDimSizeImpxCheckR2021b(i, nm1d2, &c_emlrtECI, (emlrtConstCTX)sp);
  }
  st.site = &hb_emlrtRSI;
  if (y->size[0] == x->size[0]) {
    nm1d2 = y->size[0];
    n = (nm1d2 / 2) << 1;
    k = n - 2;
    for (i = 0; i <= k; i += 2) {
      __m128d r1;
      r = _mm_loadu_pd(&b_y_data[i]);
      r1 = _mm_loadu_pd(&y_data[i]);
      _mm_storeu_pd(&b_y_data[i], _mm_add_pd(r, r1));
    }
    for (i = n; i < nm1d2; i++) {
      b_y_data[i] += y_data[i];
    }
  } else {
    b_st.site = &hb_emlrtRSI;
    plus(b_st, y, x);
    b_y_data = y->data;
  }
  b_st.site = &ob_emlrtRSI;
  nm1d2 = y->size[0];
  c_st.site = &v_emlrtRSI;
  overflow = (y->size[0] > 2147483646);
  if (overflow) {
    d_st.site = &g_emlrtRSI;
    coder::check_forloop_overflow_error(d_st);
  }
  for (k = 0; k < nm1d2; k++) {
    b_y_data[k] = muDoubleScalarCos(b_y_data[k]);
  }
  emxFree_real_T(sp, &x);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)sp);
}

// End of code generation (encode.cpp)
