//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// decode_mex_terminate.cpp
//
// Code generation for function 'decode_mex_terminate'
//

// Include files
#include "decode_mex_terminate.h"
#include "_coder_decode_mex_mex.h"
#include "decode_mex_data.h"
#include "rt_nonfinite.h"

// Function Definitions
void decode_mex_atexit()
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtEnterRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
  emlrtExitTimeCleanup(&emlrtContextGlobal);
}

void decode_mex_terminate()
{
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

// End of code generation (decode_mex_terminate.cpp)
