fs = 1000; 
fc = 200;  
t = (0:1/fs:0.2)';
x = sin(2*pi*30*t)+2*sin(2*pi*60*t);
freq_dev = 50;

disp((size(x, 1) - 1))
disp(((size(x, 1) - 1) / fs))

t1 = (0:1/fs:((size(x, 1) - 1) / fs))';
int_x = cumsum(x)/fs;
y = cos(2 * pi * fc * t1 + 2 * pi * freq_dev * int_x);

plot(t, y)

time = 0:1/144000:10.29;
disp(time(1481761))