function y = encode(input_information, sampling_frequency, carrier_frequency, freq_dev) %#codegen
    t = (0:1/sampling_frequency:((size(input_information, 1) - 1) / sampling_frequency))';
    t = t(:, ones(1, size(input_information, 2)));
    int_x = cumsum(input_information)/sampling_frequency;
    y = cos(2 * pi * carrier_frequency * t + 2 * pi * freq_dev * int_x);
end