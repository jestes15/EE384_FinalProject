function z = decode(input_information, sampling_frequency, carrier_frequency, freq_dev)
    t = (0:1/sampling_frequency:((size(input_information, 1) - 1) / sampling_frequency))';
    t = t(:, ones(1, size(input_information, 2)));
    
    yq = hilbert(input_information).*exp(-1i * 2 * pi * carrier_frequency * t);
    z = (1 / (2 * pi * freq_dev)) * [zeros(1, size(yq, 2)); diff(unwrap(angle(yq))) * sampling_frequency];
end




   

