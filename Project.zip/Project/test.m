Fs = 10000;
t = 0:1/Fs:1;

F1 = 100;
x = sin(2 * pi * t * F1);

y = hilbert(x);
y2 = hilb(x);

figure(1)
subplot(2, 1, 1);
plot(t, real(y));
hold on;
plot(t, imag(y));
hold off;
xlim([0 0.01]);

subplot(2, 1, 2);
plot(t, real(y2));
hold on;
plot(t, imag(y2));
hold off;
xlim([0 0.01]);


function value = hilb(x)
    fft_result = fft(x);
    length_of_x = length(x);
    h = zeros(1, length_of_x);
    for i = 1:length_of_x
        if (i == 1 || i == ((length_of_x/2) + 1))
            h(i) = 1;
        end

        if (i >= 2 && i <= (length_of_x/2))
            h(i) = 2;
        end


        if (i >= ((length_of_x/2) + 2) && i <= length_of_x)
            h(i) = 0;
        end
    end

    value = ifft(fft_result .* h);
end