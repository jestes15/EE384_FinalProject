fs = 1000;
fc = 200;
fDev = 50;
t = (0:1/fs:0.1)';
x = sin(2*pi*30*t) + 2*sin(2*pi*60*t);
int_x = cumsum(x)/fs;
xfm = cos(2*pi*fc*t).*cos(2*pi*fDev*int_x) - sin(2*pi*fc*t).*sin(2*pi*fDev*int_x);
t2 = (0:1/fs:((size(xfm,1)-1)/fs))';
t2 = t2(:,ones(1,size(xfm,2)));
xfmq = hilbert(xfm).*exp(-1i*2*pi*fc*t2);
z = (1/(2*pi*fDev)) * [zeros(1,size(xfmq,2)); diff(unwrap(angle(xfmq)))*fs];


figure(1)
plot(t, x);
set(gca,'Color','k')
title('Input of encoding function')
saveas(gca, 'encoding_input.png')


figure(2)
plot(t, xfm);
title('Output of encoding function/Input of decoding function')
saveas(gcf, 'encoding_output_decoding_input.png')


figure(3)
plot(t, z);
title('Output of decoding function')
saveas(gcf, 'decoding_output.png')
