function output = hilbert_transform(input_signal) %#codegen
    output = hilbert(input_signal);

end